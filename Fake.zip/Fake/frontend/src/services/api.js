import axios from "axios";

export const checkFakeNews = async (title, content) => {
  const response = await axios.post("http://localhost:5000/api/news/check", { title, content });
  return response.data;
};

export const checkFakeImage = async (imageUrl) => {
  const response = await axios.post("http://localhost:5000/api/image/check", { imageUrl });
  return response.data;
};
