

import mongoose from "mongoose";

const imageSchema = new mongoose.Schema({
  imageUrl: String,
  isFake: Boolean,
});

export default mongoose.model("Image", imageSchema);
