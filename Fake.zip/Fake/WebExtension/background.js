chrome.action.onClicked.addListener((tab) => {
    chrome.scripting.executeScript({
      target: { tabId: tab.id },
      function: scrapeNews,
    });
  });
  
  const scrapeNews = () => {
    chrome.runtime.sendMessage({ action: "scrapeNews" }, (response) => {
      fetch("http://localhost:5000/detect", { // Your backend API
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(response)
      })
      .then(res => res.json())
      .then(data => alert(`News is: ${data.prediction}`)) // Display result
      .catch(err => console.error("Error:", err));
    });
  };
  