import React from "react";
import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
import FakeNewsLanding from "./components/landing";
import NewsForm from "./components/Newsform";


const App = () => {
  return (
    <Router>
      <div>
        <Routes>
          <Route path="/" element={<FakeNewsLanding />} />
          <Route path="/detect" element={<NewsForm />} />

        </Routes>
      </div>
    </Router>
  );
};

export default App;