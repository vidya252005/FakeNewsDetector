import React, { useState } from "react";
import { checkFakeNews } from "../services/api";
import "../styles/Newsform.css";  // ✅ Fixed import

const NewsForm = () => {
  const [title, setTitle] = useState("");
  const [content, setContent] = useState("");
  const [result, setResult] = useState(null);

  const handleSubmit = async (e) => {
    e.preventDefault();
    const response = await checkFakeNews(title, content);
    setResult(response.isFake ? "Fake News Detected" : "News is Real");
  };

  return (
    <div className="news-form-container">
      <h2>Fake News Detection</h2>
      <form onSubmit={handleSubmit}>
        <input type="text" placeholder="Title" onChange={(e) => setTitle(e.target.value)} />
        <textarea placeholder="Content" onChange={(e) => setContent(e.target.value)} />
        <button type="submit">Check</button>
      </form>
      {result && (
        <p className={`result-message ${result === "Fake News Detected" ? "error" : "success"}`}>
          {result}
        </p>
      )}
    </div>
  );
};

export default NewsForm;
