// Extract the headline and main content
const getNewsData = () => {
    const title = document.querySelector("h1")?.innerText || "No title found";
    const paragraphs = [...document.querySelectorAll("p")].map(p => p.innerText);
    const content = paragraphs.slice(0, 5).join(" "); // Limit content to 5 paragraphs
  
    return { title, content };
  };
  
  // Send data to the background script
  chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "scrapeNews") {
      const newsData = getNewsData();
      sendResponse(newsData);
    }
  });
  