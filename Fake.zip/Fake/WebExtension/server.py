from flask import Flask, request, jsonify
import torch
from transformers import BertTokenizer, BertForSequenceClassification

app = Flask(__name__)

# Load Model
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
model = BertForSequenceClassification.from_pretrained("bert-base-uncased", num_labels=2)
model.load_state_dict(torch.load("bert_fake_news.pth", map_location=device))
model.to(device)
model.eval()

tokenizer = BertTokenizer.from_pretrained("bert-base-uncased")

def predict_fake_news(text):
    inputs = tokenizer(text, return_tensors="pt", padding="max_length", truncation=True, max_length=512)
    inputs = {key: val.to(device) for key, val in inputs.items()}
    with torch.no_grad():
        output = model(**inputs)
    prediction = torch.argmax(output.logits, dim=1).item()
    return "Fake" if prediction == 1 else "Real"

@app.route("/detect", methods=["POST"])
def detect():
    data = request.get_json()
    text = data.get("content", "")
    prediction = predict_fake_news(text)
    return jsonify({"prediction": prediction})

if __name__ == "__main__":
    app.run(debug=True)
