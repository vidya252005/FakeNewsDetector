document.getElementById("checkNews").addEventListener("click", () => {
    chrome.runtime.sendMessage({ action: "scrapeNews" }, (response) => {
      fetch("http://localhost:5000/detect", { // Your backend API
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(response)
      })
      .then(res => res.json())
      .then(data => {
        document.getElementById("result").innerText = `News is: ${data.prediction}`;
      })
      .catch(err => console.error("Error:", err));
    });
  });
  