import React from "react";
import { Link } from "react-router-dom";
import "../styles/FakeNewsLanding.css";
import detectIcon from "../images/detect.png";
import verifyIcon from "../images/verify.png";
import reportIcon from "../images/report.png";

const featuresData = [
  {
    img: detectIcon,
    title: "Detect Fake News",
    text: "Our AI model analyzes text to detect fake news with high accuracy.",
  },
  {
    img: verifyIcon,
    title: "Verify Images",
    text: "Upload images to verify whether they are authentic or AI-generated.",
  },
  {
    img: reportIcon,
    title: "Report Misinformation",
    text: "Help others by reporting suspicious news and images.",
  },
];

const FeatureCard = ({ img, title, text }) => (
  <div className="feature-card">
    <img src={img} alt={title} className="feature-img" />
    <h3>{title}</h3>
    <p>{text}</p>
  </div>
);

const FakeNewsLanding = () => {
  return (
    <div className="landing-container">
      {/* Navbar */}
      <nav className="navbar">
        <ul className="navbar-links">
          <li className="logo"> FakeShield</li>
          <li><a href="#home">Home</a></li>
          <li><a href="#features">Features</a></li>
          <li><a href="#about">About Us</a></li>
          <li><a href="#contact">Contact Us</a></li>
        </ul>
      </nav>

      {/* Hero Section */}
      <header className="hero" id="home">
        <div className="hero-content">
          <h1>FakeShield</h1>
          <p>Your Shield Against Fake News and Misinformation</p>
          <Link to="/detect" className="cta-button">Start Detection</Link>
        </div>
      </header>

      {/* Features Section */}
      <section className="features" id="features">
        <h2>Our Features</h2>
        <div className="features-grid">
          {featuresData.map((feature, index) => (
            <FeatureCard key={index} {...feature} />
          ))}
        </div>
      </section>

      {/* About Section */}
      <section className="about" id="about">
        <h2>About Us</h2>
        <p>
        FakeShield is dedicated to fighting misinformation using advanced AI-powered detection models.
        In today's digital age, fake news and manipulated content spread rapidly, causing confusion and misinformation. 
        Our mission is to create a more informed society by providing accurate, AI-driven insights that help users verify the authenticity of news articles, images, and media content.
        </p>
      </section>

      {/* Footer */}
      <footer className="footer">
        <p>© 2024 FakeShield. All rights reserved.</p>
        <div className="footer-links">
          <a href="#privacy">Privacy Policy</a>
          <a href="#terms">Terms of Service</a>
          <a href="#contact">Contact Us</a>
        </div>
      </footer>
    </div>
  );
};

export default FakeNewsLanding;
