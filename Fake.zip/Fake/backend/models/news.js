import mongoose from "mongoose";

const newsSchema = new mongoose.Schema({
  title: String,
  content: String,
  isFake: Boolean,
});

export default mongoose.model("News", newsSchema);